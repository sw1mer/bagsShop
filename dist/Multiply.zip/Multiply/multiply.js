function Multiply(options){
  // настраиваем options
  var options = {
    elem: options.elem,
    count: options.count || 10,
    title: options.title || 'ТАБЛИЦА',
    captionAlign: options.captionAlign || 'center',
    captionColor: options.captionColor || 'black',
    captionSize: options.captionSize || '1em',
  };
  

  
  // шаблон структуры - использована библиотека lodash
  var tmpl = _.template('\
    <table class="multiply">\
        <caption><%=tableTitle%></caption>\
        <% for (var i=1; i<=count; i++) { %>\
          <tr>\
            <% for (var j=1; j<=count; j++) { %>\
              <td><%=i*j%></td>\
            <% } %>\
          </tr>\
        <% } %>\
      </table>');
  
  // генерируем структуру с учетом переданных значений  
  var result = tmpl({count: options.count, tableTitle: options.title});
 

  // вливаем в элемент на страницу
  options.elem.innerHTML =  result;

  setCaptionProperty();
  
  function setCaptionProperty(){
    var caption = options.elem.querySelector('caption');
    caption.classList.add(options.captionAlign);
    caption.style.color = options.captionColor;
    caption.style.fontSize = options.captionSize;
  }
}